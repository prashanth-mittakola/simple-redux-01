import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPen } from "@fortawesome/free-solid-svg-icons";
import InputBox from "./inputBox";

const Task = () => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [description, setDescription] = useState("");

  let url = `https://api.covid19api.com/summary`;
  useEffect(() => {
    fetch(url)
      .then((data) => data.json())
      .then((data) => console.log("data", data));
  }, []);

  const submitHandler = (e) => {
    e.preventDefault();
    const person = {
      name,
      phone,
      email,
      description,
    };
    if(person.name && person.email && person.phone && person.description){
        setName("");
        setPhone("");
        setDescription("");
        setEmail("");
        console.log(person);
        alert("submit successfull");
    }else {
        alert("please add all details")
    }
  };

  return (
    <section className="main">
      <div className="top-div">
        <h2 className="edit-text">Edit Profile</h2>
        <div className="img-div-main">
          <div className="img-div">
            <img
              className="profile-image"
              src="https://mmwealth.co.za/wp-content/uploads/2014/08/Profile-Pic-Demo.png"
              alt="profile image"
            />
            {/* <div className="edit-icon"> */}
            <FontAwesomeIcon className="edit-icon" icon={faPen} />
            {/* </div> */}
          </div>
        </div>
      </div>
      <div className="bottom-div">
        <form className="form">
          <InputBox label={"Name"} type={"text"} val={name} setVal={(e)=>setName(e.target.value)}/>
          <InputBox label={"Phone"} type={"number"} val={phone} setVal={(e)=>setPhone(e.target.value)}/>
          <InputBox label={"Email"} type={"email"} val={email} setVal={(e)=>setEmail(e.target.value)}/>
          <InputBox label={"Tell Us About Yourself"} type={"textarea"} val={description} setVal={(e)=>setDescription(e.target.value)}/>
          <button className="sumbit-button" onClick={(e) => submitHandler(e)}> submit </button>
        </form>
      </div>
    </section>
  );
};

export default Task;
