import React from "react";

const InputBox = ({ val, setVal, type, label }) => {
  return (
    <div className="input-main">
      <label> {label} </label>
      <br />
      <div className="input-section">
        {type === "textarea" ? (
          <textarea
            className="input-box"
            name="description"
            rows="4"
            cols="5"
            value={val}
            onChange={setVal}
          />
        ) : (
              <input
                className="input-box"
                type={type}
                value={val}
                onChange={setVal}
              />
        )}
        <span className="g-symbol">&#62;</span>
      </div>
    </div>
  );
};

export default InputBox;
