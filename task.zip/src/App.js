import Task from './Task';
import './App.css';

function App() {
  return (
    <div className="App">
      <Task />
    </div>
  );
}

export default App;
